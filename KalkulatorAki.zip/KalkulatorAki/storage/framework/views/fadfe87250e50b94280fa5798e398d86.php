<!DOCTYPE html>
<html>
<head>
    <title>Catatan Harian</title>
</head>
<body>
    <h1>Tambah Catatan Harian</h1>

    <form method="POST" action="<?php echo e(route('catatan.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="judul" placeholder="Judul"><br><br>
        <textarea name="isi" placeholder="Isi catatan"></textarea><br><br>
        <button type="submit">Simpan</button>
    </form>

    <hr>

    <h2>Daftar Catatan:</h2>
    <ul>
        <?php $__currentLoopData = $catatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong><?php echo e($catatan->judul); ?></strong><br>
                <?php echo e($catatan->isi); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH /Users/harisuddinhakim/projectsatu/resources/views/catatan/index.blade.php ENDPATH**/ ?>